﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    DataTable dt;
    SqlDataAdapter adpt;
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=MyDb;Integrated Security=True");
        string qry="select * from MyTable where Email='"+Login1.UserName+"'and Password='"+Login1.Password+"' ";
        adpt = new SqlDataAdapter(qry,con);
        dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count >= 1)
        {
            Response.Redirect("index.aspx");
        }
    }
}